# MGIS 355 Project 1 — Andrew Rautzhan

This is a complete agent-produced project draft. Review the proposed policies and read `disclosure.md` before submitting. The memo does not claim a store is behind when the chosen rule finds none. The class checkpoint is a historical requirement; this folder does not establish that it was submitted.

## Contents

- `memo.pdf`: two-page decision memo; page one contains the fourteen-store ranking.
- `model/model.md`: bus matrix, grain statements and modeling rules.
- `model/build_star.py`: repeatable source-to-star build.
- `model/ridgeline_star.duckdb`: built dimensional model, separate from raw data.
- `metrics.md`: complete seven-field metric entries, including sensitivities and a conversion rate.
- `analysis.ipynb`: executed SQLAlchemy / pandas notebook with bound query parameters.
- `verification.md`: three traced memo figures, inherited query audit, reconciliation and executed checks.
- `disclosure.md`: accurate account of agent work and missing student review.
- `results/`: full-precision ranking/conversion CSVs, reconciliation SQL and machine-readable evidence.
- `data/`: original source database, dictionary and inherited queries. Only filenames changed for portable paths; contents match the supplied files.

## Reproduce

Use Python 3.12 (tested: 3.12.14) in a virtual environment. From this folder:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
python model/build_star.py
jupyter nbconvert --to notebook --execute analysis.ipynb --inplace --ExecutePreprocessor.timeout=120
python verify.py
python model/sensitivities.py
python model/render_reports.py
```

The source is always read-only. The build accepts `--source /path/to/source.duckdb` and `--output /path/to/separate.duckdb`; defaults are relative to this folder, independent of the shell working directory. Execute the notebook from this folder. The renderer refreshes the supplied metrics, verification, disclosure and memo; save any manual edits before rerunning it. It is specific to this delivered extract, not a generic report for arbitrary refreshed data. The memo’s date is October 18, 2026.

`verify.py` rebuilds twice over the output and once into a fresh temporary file, compares all logical contents, checks fact/dimension relationships, independently queries raw data and confirms exact source/star reconciliation. It also records the source SHA-256. Notebook outputs were produced by real execution, not filled in manually. `requirements.txt` records direct dependencies; `requirements-lock.txt` records the complete tested environment.

## Decisions to understand

Carryout credits the selling store, BOPIS the pickup store, and shipped web stays separate. Net revenue deducts line markdowns and observed refunds, excluding unreconciled order promotions, shipping and tax. Sales use Eastern dates; refunds follow the original sale cohort. Q3 targets are allocated by 62/92 days and a store is flagged below 95% of pace. These are proposed policies, with seasonal target pacing and future returns explicitly unresolved. Read the memo’s second page and the metric register for alternatives.

The upload names contained spaces and suffixes. `data/ridgeline.duckdb` is byte-identical to `ridgeline (3).duckdb`; the root repository originals are untouched. The source database is included so the build can run on a clean machine without external credentials or downloads beyond Python packages.
