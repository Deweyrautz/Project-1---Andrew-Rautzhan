# Verification record

All checks below were executed with the delivered source and star; `python verify.py` repeats them. Source SHA-256: `4e77358199dff31e9d4089b5318ea8d604543db5c413e25b8dca150f31682adb`. The raw source is opened read-only. The SQL ledger below reads only raw source tables and does not use star tables or views.

## Three memo numbers traced independently

The query below takes four bound parameters: `2026-07-01`, `2026-09-01`, repeated for the refund branch. It treats sales as positive ledger entries and refunds as negative entries, rather than reusing the star’s line/refund join.

```sql
WITH ledger AS (
 SELECT CASE WHEN o.fulfillment='carryout' THEN coalesce(o.selling_store_id,0)
             WHEN o.fulfillment='bopis' THEN coalesce(o.pickup_store_id,0) ELSE 0 END store_id,
        i.quantity*i.unit_price-i.line_discount AS amount
 FROM orders o JOIN order_items i USING(order_id)
 WHERE o.order_status='completed'
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE>=CAST(? AS DATE)
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE<CAST(? AS DATE)
 UNION ALL
 SELECT CASE WHEN o.fulfillment='carryout' THEN coalesce(o.selling_store_id,0)
             WHEN o.fulfillment='bopis' THEN coalesce(o.pickup_store_id,0) ELSE 0 END,
        -r.refund_amount
 FROM returns r JOIN order_items i USING(order_item_id) JOIN orders o USING(order_id)
 WHERE o.order_status='completed'
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE>=CAST(? AS DATE)
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE<CAST(? AS DATE)
)
SELECT store_id,sum(amount) AS net_revenue FROM ledger GROUP BY store_id ORDER BY store_id
```

1. **Burlington observed net revenue: $809,202.32.** Select store_id 101 from the ledger result; agrees exactly with the star/memo. No joining to customers excludes cash orders.
2. **Company observed net revenue: $9,786,567.01.** Sum all ledger store rows, including store 0; agrees exactly with the star/memo. Difference: $0.00.
3. **Burlington target attainment: 120.7%.** Use the independent $809,202.32 ledger result and query the raw target as below. Raw quarterly target is $995,000.00. Multiply by 62/92 for $670,543.4782608696; divide raw revenue by that unrounded result for 120.6785758469768%. Agrees with star to floating-point precision and memo to one decimal. Do not compute attainment from a rounded target.

```sql
SELECT revenue_target FROM store_targets
WHERE store_id = ? AND fiscal_year = ? AND fiscal_quarter = ?;
-- Bound values: 101, 2026, 3
```

## Inherited query audit: Query A

**Header claim, separated from the SQL interpretation:** total promotional discount given by district for Q3 FY2026 to date, used to argue District 1 is overspending.

**Actual result:** sums each completed, store-sold order’s order-level discount once per joined order item. It measures item-count-weighted order discounts in the stated UTC interval. An order with three lines repeats its promotion three times. District dimension joins retain store-sold orders only.

**Failure taxonomy:** silent fan-out from orders to order_items. The correction below removes only that unnecessary join. It intentionally keeps the inherited selling-store attribution, UTC window, and completed filter so the quantified difference isolates the fan-out. A company-wide Eastern-date promotion report would be a separate definition and is not claimed here.

Original SQL is Query A in `data/queries_to_audit.sql`, executed unchanged using DuckDB’s statement parser. Corrected SQL:

```sql
SELECT s.district_id,round(sum(o.discount_amount),2) AS promo_discount
FROM orders o JOIN stores s ON s.store_id=o.selling_store_id
WHERE o.order_status='completed' AND o.order_ts>='2026-07-01' AND o.order_ts<'2026-09-01'
GROUP BY s.district_id ORDER BY s.district_id
```

| District | Inherited output | Corrected output | Dollar overstatement | Percent overstatement |
|---|---:|---:|---:|---:|
| 1 | $75,480.59 | $24,314.03 | $51,166.56 | 210.4% |
| 2 | $53,925.23 | $18,371.28 | $35,553.95 | 193.5% |
| 3 | $53,767.33 | $17,597.74 | $36,169.59 | 205.5% |

District 1 still has the largest total after correction. That does not establish overspending: the query contains no budget or comparison with a promotion allowance.

## Reconciliation

| Scope | Independent raw ledger | Star | Difference |
|---|---:|---:|---:|
| Fourteen physical stores | $8,343,124.19 | $8,343,124.19 | $0.00 |
| Shipped web / unattributed store 0 | $1,443,442.82 | $1,443,442.82 | $0.00 |
| Company | $9,786,567.01 | $9,786,567.01 | $0.00 |

Every one of the fifteen store/bucket totals matches exactly as Decimal values, not only the grand total. Physical stores plus store 0 equal company revenue; the store ranking does not purport to sum to company revenue without that bucket.

## Build and relationship checks

Passed: build twice over the existing output with identical sorted logical content in every table/view; build to a fresh temporary database with identical content; unchanged source file hash; 22 dimension-role relationship checks; all five fact/source row counts; unique sale/order/return and dimension keys; unique traffic store-day and target store-quarter keys; sale_net retains exactly one row per sold line; no orphan raw returns; traffic coverage for every completed carryout store-day in the selected window; notebook cells executed without error. Logical content, not DuckDB file bytes, defines deterministic results because database storage metadata can vary.

No tests were skipped or marked expected failure. No historical membership or margin claims are tested because the extract cannot support them. This validation checks implemented definitions, not institutional approval of the policies.

## Sensitivities and limits

- Line revenue before refunds is $10,309,394.13 company-wide; recorded cohort refunds are $522,827.12, yielding $9,786,567.01. Subtracting the additional $88,999.46 of order promotions would give $9,697,567.55, but could double-count discounts. Shipping $16,246.10 and tax $715,448.00 stay outside revenue.
- Eastern-window company line revenue is $10,309,394.13 versus $10,304,284.88 using the UTC window: a $5,109.25 difference. This is a controlled line-revenue calendar comparison, not a net-revenue difference.
- Company matched-prior Jul–Aug net is $8,815,381.38. Full prior Q3 net is $14,502,185.23. Current net implies 11.0% matched-window growth, versus -32.5% against the longer prior quarter.
- Burlington carryout-only net is $622,467.07 (92.8% of pace); BOPIS adds $186,735.25 and 27.8 percentage points, taking it to 120.7%. Under the carryout-only alternative, Burlington and Plattsburgh would cross the below-95% flag; under the selected rule neither does.
- Burlington’s $809,202.32 is only 81.3% of its whole-quarter target, versus 120.7% of the 62/92 allocated target. The allocation changes the meaning of the comparison; it does not change revenue.
- The latest observed local return date is October 14, 2026. That is an observation, not the known exact extract timestamp. Cohort net values can still move with later returns; 2025 and 2026 refunds have different maturation time.
- Targets have no documented channel or gross/net basis. Seasonal sales pacing is absent. Conclusions about being “behind” are conditional on the stated allocation and revenue basis; none justifies closing a department or guaranteeing quarter-end performance.
