
WITH sales AS (
 SELECT credit_store_id AS store_id,sale_date AS business_date,count(*) AS transactions
 FROM fact_order WHERE order_status=:status AND fulfillment=:carryout
 AND sale_date>=:start AND sale_date<:end GROUP BY credit_store_id,sale_date
), traffic AS (
 SELECT store_id,business_date,sum(visitor_count) AS visitors FROM fact_traffic
 WHERE business_date>=:start AND business_date<:end GROUP BY store_id,business_date
)
SELECT s.store_code,sum(coalesce(o.transactions,0)) AS transactions,sum(t.visitors) AS visitors,
       100.0*sum(coalesce(o.transactions,0))/nullif(sum(t.visitors),0) AS conversion_pct
FROM traffic t JOIN dim_store s USING(store_id)
LEFT JOIN sales o USING(store_id,business_date)
GROUP BY s.store_code ORDER BY s.store_code
