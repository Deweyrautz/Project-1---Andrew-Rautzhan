
WITH actual AS (
 SELECT credit_store_id AS store_id,sum(net_revenue) AS net_revenue,
        sum(line_revenue) AS line_revenue,sum(refund_amount) AS refunds
 FROM sale_net WHERE order_status=:status AND sale_date>=:start AND sale_date<:end
 GROUP BY credit_store_id
), prior AS (
 SELECT credit_store_id AS store_id,sum(net_revenue) AS prior_net
 FROM sale_net WHERE order_status=:status AND sale_date>=:prior_start AND sale_date<:prior_end
 GROUP BY credit_store_id
), targets AS (
 SELECT store_id,revenue_target,revenue_target*:elapsed/:quarter_days AS pace_target
 FROM fact_target WHERE quarter_key=:quarter_key
)
SELECT s.store_id,s.store_code,s.store_name,coalesce(a.net_revenue,0) AS net_revenue,
       coalesce(a.line_revenue,0) AS line_revenue,coalesce(a.refunds,0) AS refunds,
       t.revenue_target,t.pace_target,100.0*coalesce(a.net_revenue,0)/t.pace_target AS attainment_pct,
       coalesce(a.net_revenue,0)-t.pace_target AS gap,
       p.prior_net,100.0*(a.net_revenue/nullif(p.prior_net,0)-1) AS yoy_pct,
       CASE WHEN a.net_revenue/t.pace_target<:threshold THEN 'Below pace' ELSE 'Within tolerance' END AS flag
FROM dim_store s JOIN targets t USING(store_id)
LEFT JOIN actual a USING(store_id) LEFT JOIN prior p USING(store_id)
ORDER BY attainment_pct DESC,s.store_code
