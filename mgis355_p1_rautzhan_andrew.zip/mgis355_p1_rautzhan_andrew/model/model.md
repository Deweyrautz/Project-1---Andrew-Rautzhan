# Model contract

Grain statements were specified before the build queries:

- `fact_sale`: one row per source order item, including cancelled orders for explicit filtering.
- `fact_order`: one row per checkout event, preserving order-level amounts without line fan-out.
- `fact_return`: one row per recorded return event for an order item; multiple events can refer to the same sold line.
- `fact_traffic`: one row per physical store per local business date.
- `fact_target`: one row per physical store per fiscal quarter.

| Fact | Store | Product | Customer | Date | Quarter |
|---|---|---|---|---|---|
| sale | credit, selling, pickup | yes | yes | sale | via sale date |
| order | credit, selling, pickup | — | yes | sale, pickup | via sale date |
| return | original credit, return location | yes | yes | original sale, return | via dates |
| traffic | physical store | — | — | business date | via business date |
| target | physical store | — | — | — | target quarter |

Store and date are role-playing dimensions. Keys retain source IDs. Store 0 captures shipped web orders and absent store roles; customer 0 preserves anonymous buyers. These rows do not imply a physical store or known customer. Product/customer attributes reflect extract-time state, not historical membership or cost. No historical margin or membership claim is made.

The calendar assumes fiscal quarters equal calendar quarters (the provided Q3 periods). Dates resolve UTC timestamps using `America/New_York`, not a fixed offset. Traffic already carries local dates. The date dimension covers 2025–2027; validation rejects unmatched dates if future data exceed that range.

`sale_net` first sums returns to one row per order item, then left joins sales. It therefore retains unreturned and anonymous sales and cannot multiply lines through repeated return events. Returned quantity and refund measures follow return events, not order status. Net metrics select completed original orders and assign all observed refunds to the original sale cohort, even when the return occurs later. Return-location credit is retained as a separate role.

Never directly join traffic, targets, or raw returns to sales and sum both sides. Aggregate each fact independently to the common store/date or store/quarter grain first. Order discounts remain in `fact_order`; they are deliberately not allocated or subtracted from line revenue because overlap with line discounts is undocumented. Source timestamps remain available in `fact_order` for timezone sensitivity checks.
