from pathlib import Path
import json, csv, html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
P=Path(__file__).resolve().parents[1]
v=json.loads((P/'results/verification_results.json').read_text())
s=json.loads((P/'results/sensitivities.json').read_text())
rows=list(csv.DictReader((P/'results/store_ranking.csv').open()))
money=lambda x:f'${float(x):,.2f}'
pct=lambda x:f'{float(x):.1f}%'
# Each entry has the seven fields mandated by the assignment.
metrics=[]
def metric(name,formula,grain,filters,credit,calendar,owner):
    metrics.append(f'## {name}\n\n| Field | Definition |\n|---|---|\n| Name | {name} |\n| Formula | `{formula}` |\n| Grain | {grain} |\n| Filters | {filters} |\n| Store credit rule | {credit} |\n| Calendar | {calendar} |\n| Owner and status | {owner} |\n')
base="Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1."
credit="Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it."
cal="sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date."
metric('Line revenue after line markdowns','SUM(fact_sale.quantity * fact_sale.unit_price - fact_sale.line_discount)', 'One sold line; additive to store/period',base+' Exclude order discount_amount, shipping_amount and tax_amount because overlap/policy is unresolved.',credit,cal,'Finance controller; provisional pending discount reconciliation')
metric('Observed cohort refunds','SUM(fact_return.refund_amount)','One return event; aggregate by original sale cohort before joining to sales',base+' Include every recorded refund for eligible sold lines, even after August 31; no return-date cutoff. Never infer refunds from order_status.',credit+' Returns debit the original credit store, not return_store_id.',cal+' Extract metadata says mid-October; last observed local return date is October 14, 2026, which is not proof of an exact extraction timestamp.','Finance controller; provisional as late returns remain possible')
metric('Observed net merchandise revenue','SUM(sale_net.line_revenue) - SUM(sale_net.refund_amount)','One sold line in sale_net, after returns are summed per line',base+' Only line markdowns and recorded refunds deducted; order promotions, tax and shipping excluded. Not GAAP revenue.',credit,cal,'Finance controller; provisional, refund maturity differs across years')
metric('Quarter revenue target','MAX(fact_target.revenue_target) per store-quarter; SUM across distinct stores','One store per quarter, never sum after line joins','Select quarter_key=20263; retain all fourteen physical stores; no sales-based store filtering','Target belongs to physical store_id; web bucket has no target','Fiscal Q3 assumed July–September; quarterly target provided, intraperiod schedule absent','VP of Stores / FP&A; source target accepted, comparability to net merchandise revenue provisional')
metric('Elapsed-period target','fact_target.revenue_target * 62.0 / 92.0','One store per target quarter','Q3 2026 only; 62 days elapsed; no seasonality or trading-day adjustment','Physical target store_id','July 1–September 1 elapsed; July 1–October 1 quarter, Eastern calendar dates','FP&A; provisional linear day allocation, not a forecast')
metric('Target attainment','100 * store_net_revenue / NULLIF(elapsed_period_target,0)','Store-period after independent fact aggregation',base+' Numerator is observed net merchandise revenue; denominator from the selected quarter. No order/target fan-out.',credit,cal,'VP of Stores / FP&A; provisional until target basis and seasonality approved')
metric('Dollar gap to pace','store_net_revenue - elapsed_period_target','Store-period',base+' Positive means ahead; no tolerance applied to the dollar gap.',credit,cal,'VP of Stores / FP&A; provisional')
metric('Below-pace flag and ranking','attainment_pct < 95; rank stores by attainment_pct DESC, store_code ASC','Store-period','Include all fourteen stores; unrounded attainment determines flag; equality at 95 is within tolerance. Count flags, not rows of sales.',credit,cal,'VP of Stores; proposed 5 percentage point tolerance, not a statistical significance claim')
metric('Matched-window net growth','100 * (current_net / NULLIF(prior_matched_net,0) - 1)','Store-period or company-period, same aggregation on both sides',base+' Compare Jul–Aug with Jul–Aug, not the entire prior quarter. All observed cohort refunds included, with unequal maturity caveat.',credit,cal,'FP&A; provisional due to refund maturation and attribution policy')
metric('Carryout-only net revenue and attainment','SUM(sale_net.net_revenue) WHERE fulfillment=carryout; 100 * carryout_net / elapsed_period_target','Store-period',base+' Additional fulfillment=carryout; sensitivity alternative, not primary ranking. Same target and refunds basis.', 'Selling store only; excludes BOPIS and shipped web',cal,'VP of Stores; rejected as primary store-credit definition')
metric('BOPIS net credit and attribution lift','SUM(sale_net.net_revenue) WHERE fulfillment=bopis; bopis_net = credited_net - carryout_net; attainment_lift_pp = 100 * bopis_net / elapsed_period_target','Store-period',base+' Additional fulfillment=bopis; no pickup-date filter; includes its observed refunds.','Pickup store',cal,'Omnichannel operations; provisional original-order-date credit rule')
metric('Carryout transactions','COUNT(fact_order.order_id) WHERE fulfillment=carryout','One completed carryout order; aggregate first to store-day',base+' Additional fulfillment=carryout; count checkout events, not customers or lines. Never join raw orders to traffic.', 'Selling store',cal,'Retail operations; proposed checkout measure')
metric('Door visitors','SUM(fact_traffic.visitor_count)','Store-local-day, additive to period','July–August 2026 traffic rows; all fourteen stores; no order or customer filter. Verify every sales day has traffic.', 'Physical store_id','fact_traffic.business_date is already local; do not timezone-shift it','Retail operations; source door-counter measure, includes nonbuyers and possibly pickups')
metric('Carryout conversion proxy','100 * SUM(store_day_carryout_transactions) / NULLIF(SUM(store_day_visitors),0)','Store-period after store-day aggregation','Same traffic-covered days in numerator and denominator; left join aggregated orders onto traffic, retaining zero-order days; do not average daily percentages.', 'Physical store / selling store',cal+' Traffic uses its local business_date.','Retail operations; provisional proxy, not person-level conversion; repeat visits and BOPIS traffic affect interpretation')
metric('UTC-window line revenue sensitivity','SUM(fact_sale.line_revenue) WHERE fact_order.order_ts >= start_utc AND fact_order.order_ts < end_utc','Company-period',base+' Replace local-date window only; keep line revenue definition, not net revenue. Comparison uses the same company scope.',credit,'UTC timestamps in [2026-07-01 00:00, 2026-09-01 00:00); rejected primary calendar','Finance controller; diagnostic, not approved operating calendar')
metric('Full-prior-quarter growth sensitivity','100 * (current_JulAug_net / NULLIF(prior_JulSep_net,0) - 1)','Company-period','Current Jul–Aug 2026 versus Jul–Sep 2025; completed orders and observed refunds as above; deliberately unequal windows',credit,cal,'FP&A; rejected comparability alternative')
metric('Whole-quarter attainment sensitivity','100 * store_net_revenue / NULLIF(quarter_revenue_target,0)','Store-period',base+' Full-quarter denominator without elapsed-day allocation; diagnostic only',credit,cal,'FP&A; rejected comparison for partial-quarter performance')
metric('Additional-order-promotion sensitivity','company_observed_net - SUM(fact_order.discount_amount)','Company-period after separate order and line aggregation',base+' Subtract order promotions once per order; shipping and tax remain excluded. Overlap with line discounts is unknown.',credit,cal,'Finance controller; unresolved sensitivity, not approved revenue')
metric('Order promotions by district, audited Query A','SUM(fact_order.discount_amount) per district, without joining order lines','Completed order, additive to district-period','Match inherited audit scope exactly: UTC Jul–Aug 2026; completed orders with a selling store. Deliberately excludes web orders so only fan-out changes.','Selling-store district, not primary omnichannel credit rule','UTC order_ts window, preserved from inherited Query A for controlled audit','Finance controller; corrected for audit scope only, not a complete company promotions report')
metric('Audit overstatement','wrong_promo - corrected_promo; 100 * (wrong_promo / NULLIF(corrected_promo,0) - 1)','District audit result','Same scope as audited promotions; wrong output repeats each order amount once per item','Selling-store district','Inherited UTC window','Analytics reviewer; verified diagnostic')
(P/'metrics.md').write_text('# Metric register\n\nAll reported monetary values are dollars. Display rounding happens after aggregation. Definitions are proposed analytical policies, not statements of Ridgeline’s approved accounting policy. Company and physical-store scopes must not be interchanged.\n\n'+'\n'.join(metrics))
raw=(P/'results/source_reconciliation.sql').read_text()
auditfixed=(P/'results/audit_A_corrected.sql').read_text()
auditrows='\n'.join(f"| {a['district']} | {money(a['wrong'])} | {money(a['correct'])} | {money(a['overstatement'])} | {pct(a['pct'])} |" for a in v['audit_A'])
verification=f'''# Verification record

All checks below were executed with the delivered source and star; `python verify.py` repeats them. Source SHA-256: `{v['source_sha256']}`. The raw source is opened read-only. The SQL ledger below reads only raw source tables and does not use star tables or views.

## Three memo numbers traced independently

The query below takes four bound parameters: `2026-07-01`, `2026-09-01`, repeated for the refund branch. It treats sales as positive ledger entries and refunds as negative entries, rather than reusing the star’s line/refund join.

```sql
{raw.strip()}
```

1. **Burlington observed net revenue: {money(v['burlington_net'])}.** Select store_id 101 from the ledger result; agrees exactly with the star/memo. No joining to customers excludes cash orders.
2. **Company observed net revenue: {money(v['company_net'])}.** Sum all ledger store rows, including store 0; agrees exactly with the star/memo. Difference: $0.00.
3. **Burlington target attainment: {pct(v['burlington_attainment_pct'])}.** Use the independent $809,202.32 ledger result and query the raw target as below. Raw quarterly target is $995,000.00. Multiply by 62/92 for $670,543.4782608696; divide raw revenue by that unrounded result for 120.6785758469768%. Agrees with star to floating-point precision and memo to one decimal. Do not compute attainment from a rounded target.

```sql
SELECT revenue_target FROM store_targets
WHERE store_id = ? AND fiscal_year = ? AND fiscal_quarter = ?;
-- Bound values: 101, 2026, 3
```

## Inherited query audit: Query A

**Header claim, separated from the SQL interpretation:** total promotional discount given by district for Q3 FY2026 to date, used to argue District 1 is overspending.

**Actual result:** sums each completed, store-sold order’s order-level discount once per joined order item. It measures item-count-weighted order discounts in the stated UTC interval. An order with three lines repeats its promotion three times. District dimension joins retain store-sold orders only.

**Failure taxonomy:** silent fan-out from orders to order_items. The correction below removes only that unnecessary join. It intentionally keeps the inherited selling-store attribution, UTC window, and completed filter so the quantified difference isolates the fan-out. A company-wide Eastern-date promotion report would be a separate definition and is not claimed here.

Original SQL is Query A in `data/queries_to_audit.sql`, executed unchanged using DuckDB’s statement parser. Corrected SQL:

```sql
{auditfixed.strip()}
```

| District | Inherited output | Corrected output | Dollar overstatement | Percent overstatement |
|---|---:|---:|---:|---:|
{auditrows}

District 1 still has the largest total after correction. That does not establish overspending: the query contains no budget or comparison with a promotion allowance.

## Reconciliation

| Scope | Independent raw ledger | Star | Difference |
|---|---:|---:|---:|
| Fourteen physical stores | {money(v['physical_store_net'])} | {money(v['physical_store_net'])} | $0.00 |
| Shipped web / unattributed store 0 | {money(v['web_net'])} | {money(v['web_net'])} | $0.00 |
| Company | {money(v['company_net'])} | {money(v['company_net'])} | $0.00 |

Every one of the fifteen store/bucket totals matches exactly as Decimal values, not only the grand total. Physical stores plus store 0 equal company revenue; the store ranking does not purport to sum to company revenue without that bucket.

## Build and relationship checks

Passed: build twice over the existing output with identical sorted logical content in every table/view; build to a fresh temporary database with identical content; unchanged source file hash; {v['foreign_key_roles_checked']} dimension-role relationship checks; all five fact/source row counts; unique sale/order/return and dimension keys; unique traffic store-day and target store-quarter keys; sale_net retains exactly one row per sold line; no orphan raw returns; traffic coverage for every completed carryout store-day in the selected window; notebook cells executed without error. Logical content, not DuckDB file bytes, defines deterministic results because database storage metadata can vary.

No tests were skipped or marked expected failure. No historical membership or margin claims are tested because the extract cannot support them. This validation checks implemented definitions, not institutional approval of the policies.

## Sensitivities and limits

- Line revenue before refunds is $10,309,394.13 company-wide; recorded cohort refunds are $522,827.12, yielding $9,786,567.01. Subtracting the additional $88,999.46 of order promotions would give $9,697,567.55, but could double-count discounts. Shipping $16,246.10 and tax $715,448.00 stay outside revenue.
- Eastern-window company line revenue is $10,309,394.13 versus $10,304,284.88 using the UTC window: a $5,109.25 difference. This is a controlled line-revenue calendar comparison, not a net-revenue difference.
- Company matched-prior Jul–Aug net is $8,815,381.38. Full prior Q3 net is $14,502,185.23. Current net implies {pct((float(s['comparison'][0][2])/float(s['comparison'][0][0])-1)*100)} matched-window growth, versus {pct((float(s['comparison'][0][2])/float(s['comparison'][0][1])-1)*100)} against the longer prior quarter.
- Burlington carryout-only net is $622,467.07 (92.8% of pace); BOPIS adds $186,735.25 and 27.8 percentage points, taking it to 120.7%. Under the carryout-only alternative, Burlington and Plattsburgh would cross the below-95% flag; under the selected rule neither does.
- Burlington’s $809,202.32 is only 81.3% of its whole-quarter target, versus 120.7% of the 62/92 allocated target. The allocation changes the meaning of the comparison; it does not change revenue.
- The latest observed local return date is October 14, 2026. That is an observation, not the known exact extract timestamp. Cohort net values can still move with later returns; 2025 and 2026 refunds have different maturation time.
- Targets have no documented channel or gross/net basis. Seasonal sales pacing is absent. Conclusions about being “behind” are conditional on the stated allocation and revenue basis; none justifies closing a department or guaranteeing quarter-end performance.
'''
(P/'verification.md').write_text(verification)
(P/'disclosure.md').write_text('''# AI disclosure — agent-produced work

At the user’s request, an OpenAI Codex agent produced the complete initial submission: the proposed metric policies, dimensional model and build script, SQL and executed notebook, memo, metric register, automated checks, query audit, and packaging. The agent also extracted the assignment requirements and ran the delivered code. No student-written analysis, comments-first notebook plan, framing draft, or earlier checkpoint was provided in this conversation.

The user supplied the assignment files and requested the whole project. The user’s own interpretation, independent verification, policy approval, and overrides have not yet been recorded. This disclosure therefore does not claim that Andrew designed these choices, personally checked the numbers, or completed the checkpoint. Before submitting, Andrew should read the artifacts, reproduce the traced numbers, and add an accurate account of any actual review or changes. The original agent-produced artifacts should not be represented as unaided student work.

One concrete agent error occurred during implementation: the first build attempted a bound parameter in DuckDB’s ATTACH statement, which the SQL parser rejects. The agent corrected this by quoting only the filesystem literal (with embedded quotes escaped) for ATTACH. Analytical query values in the notebook remain bound parameters. The subsequent clean build, repeated builds, and notebook execution passed. Business-policy assumptions remain provisional even after code validation.
''')
# Memo, intentionally two fixed pages.
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodySmall',fontName='Helvetica',fontSize=9,leading=12,spaceAfter=7))
styles.add(ParagraphStyle(name='SmallTitle',fontName='Helvetica-Bold',fontSize=16,leading=19,spaceAfter=9,textColor=colors.HexColor('#173c50')))
styles.add(ParagraphStyle(name='Label',fontName='Helvetica-Bold',fontSize=10,leading=13,spaceAfter=5,textColor=colors.HexColor('#173c50')))
story=[]
def para(s,style='BodySmall'):story.append(Paragraph(s,styles[style]))
def section(s):para(s,'Label')
para('Ridgeline | Q3 store review','SmallTitle')
para('TO: VP of Stores &nbsp; | &nbsp; October 18, 2026 &nbsp; | &nbsp; Analysis: July–August 2026')
para('<b>No store is below the proposed pace threshold after pickup sales receive store credit.</b> Keep all fourteen stores off an immediate remediation list. Investigate Plattsburgh’s comparable sales decline and validate the target basis before making staffing or footprint decisions. These are partial-quarter results, not a quarter-end forecast.')
para('Credit carryout to the selling store and buy-online-pick-up-in-store (BOPIS) to the pickup store. Burlington earns <b>$809,202.32</b>, or <b>120.7%</b> of its elapsed-period target. Carryout alone shows $622,467.07 and 92.8%; BOPIS restores $186,735.25 and 27.8 percentage points. Marcus’s attribution complaint is material.')
section('All fourteen stores, ranked by target attainment')
data=[['Rank / store','Observed net','Pace target','Attain.','Gap to pace','YoY']]
for i,r in enumerate(rows,1):
    data.append([f"{i}. {r['store_name']}",f"${float(r['net_revenue']):,.0f}",f"${float(r['pace_target']):,.0f}",pct(r['attainment_pct']),f"+${float(r['gap']):,.0f}",f"{float(r['yoy_pct']):+.1f}%"])
t=Table(data,colWidths=[128,79,79,53,85,48],repeatRows=1)
t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#173c50')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTNAME',(0,1),(-1,-1),'Helvetica'),('FONTSIZE',(0,0),(-1,-1),8),('LEADING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ALIGN',(1,0),(-1,-1),'RIGHT'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#eef4f5'),colors.white]),('LINEBELOW',(0,-1),(-1,-1),0.5,colors.HexColor('#a2b8c1'))]))
story.append(t);story.append(Spacer(1,10))
para('<b>Watch Plattsburgh:</b> it is last at 111.5% of pace and down 5.6% against the same months in 2025. Burlington ranks 13th but is up 7.9%. Neither crosses the below-95% threshold. Ask district managers to examine Plattsburgh’s demand and assortment; the data do not justify a closure.')
para('<b>Reading the table:</b> net merchandise sales deduct line markdowns and all observed refunds against these sales. Targets are allocated 62/92 by calendar days. YoY uses July–August in both years. Display dollars are rounded; calculations use full precision. Shipped web is excluded from the store ranking: $8,343,124.19 physical-store net + $1,443,442.82 web = $9,786,567.01 company net.')
para('<b>Before acting:</b> FP&amp;A must approve the net-versus-target basis, discount treatment, and seasonal pacing. Returns observed through the mid-October extract can still grow. Re-run after September and later returns arrive; do not treat an unallocated full-quarter target as a July–August shortfall.')
story.append(PageBreak())
para('Decision framing and policy choices','SmallTitle')
for title,body in [
('Decision','Which stores need operational intervention in the district review; do not decide department closures from this extract alone.'),
('Decision maker','VP of Stores, with district managers executing follow-up and the Finance controller / FP&A approving the metric and target basis.'),
('What would change the decision','A store falling below the 95% pace threshold after credit is corrected; materially different results under approved seasonal targets, reconciled discounts, September trading, or later returns.'),
('Metric','Observed net merchandise revenue divided by the elapsed-period store target. Use matched-window net growth as a supporting signal, not a substitute for target attainment.'),
('Threshold','Flag unrounded attainment below 95% of a day-allocated target. The five-point tolerance is a proposed management rule, not a confidence interval; none of the fourteen stores crosses it.')]:
    para(f'<b>{title}.</b> {body.replace(chr(38), chr(38)+"amp;")}')
section('Five decisions, including the rejected alternative')
for title,body in [
('1. Store credit','Carryout credits the selling store; BOPIS credits the pickup store on the order date; shipped web stays in an unattributed bucket. Selling-store-only credit rejects $186,735.25 of Burlington BOPIS net and would move Burlington below the threshold; using the return location would shift historical credit when goods are returned.'),
('2. Revenue','Deduct line discounts and observed line refunds, exclude cancelled orders, tax, shipping and unreconciled order promotions; this is an analytical merchandise measure, pending Finance approval. Company line revenue of $10,309,394.13 falls by $522,827.12 of refunds; additionally subtracting $88,999.46 of order promotions risks counting overlapping discounts twice.'),
('3. Grain','Keep separate order, sold-line, return-event, store-day traffic and store-quarter target facts; sum returns per sold line before joining. Joining order-level measures to lines is rejected: inherited Query A inflates District 1 promotions from $24,314.03 to $75,480.59, an excess of $51,166.56.'),
('4. Calendar','Resolve UTC order timestamps to America/New_York business dates; attribute refunds to the original sale cohort while retaining return dates separately. Keeping UTC boundaries would reduce July–August company line revenue by $5,109.25; a return-date ledger instead answers when refunds occurred, not what this sales cohort earned.'),
('5. Comparability','Use July–August in both years and allocate Q3 targets by 62/92 days, with no implied seasonal forecast. Comparing current company net with the full prior quarter would imply -32.5% instead of +11.0% matched growth; Burlington is 81.3% of its whole-quarter target but 120.7% of its elapsed target.')]:
    para(f'<b>{title}.</b> {body.replace(chr(38), chr(38)+"amp;")}')
section('Interpretation and ownership')
para('Definitions are provisional. Targets may embody a different channel or revenue policy, equal daily pacing ignores seasonality, and 2026 cohort returns are less mature than 2025 returns. Keep cash buyers, web revenue, and late refunds visible; do not infer past membership or margin from current-state attributes. Finance should approve the definitions before the ranking becomes a recurring scorecard.')
para('Agent assistance and validation are disclosed in disclosure.md and verification.md. The model, executable build and SQLAlchemy notebook accompany this memo.')
def footer(canvas,doc):
    canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#52707d'));canvas.drawString(42,27,'Ridgeline Outfitters | Proposed analytical definitions');canvas.drawRightString(570,27,str(doc.page))
SimpleDocTemplate(str(P/'memo.pdf'),pagesize=letter,rightMargin=40,leftMargin=40,topMargin=32,bottomMargin=40).build(story,onFirstPage=footer,onLaterPages=footer)
print('Wrote metrics, verification, disclosure and memo')
