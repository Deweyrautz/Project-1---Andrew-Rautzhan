"""Build a separate deterministic DuckDB star; never modify the source extract."""
from pathlib import Path
import argparse
import duckdb

ROOT = Path(__file__).resolve().parents[1]

def build(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    if source == output:
        raise ValueError('Source and output must differ')
    if not source.is_file():
        raise FileNotFoundError(source)
    output.parent.mkdir(parents=True, exist_ok=True)
    with duckdb.connect(str(output)) as c:
        # DuckDB ATTACH does not support bind parameters; quote the filesystem literal.
        literal = "'" + str(source).replace("'", "''") + "'"
        c.execute('ATTACH ' + literal + ' AS src (READ_ONLY)')
        c.execute('BEGIN')
        c.execute("""
        CREATE OR REPLACE TABLE dim_store AS SELECT * FROM src.stores;
        INSERT INTO dim_store (store_id,store_code,store_name) VALUES (0,'WEB','Unattributed web / unknown');
        CREATE OR REPLACE TABLE dim_product AS SELECT * FROM src.products;
        CREATE OR REPLACE TABLE dim_customer AS SELECT * FROM src.customers;
        INSERT INTO dim_customer (customer_id,basecamp_status) VALUES (0,'unknown');
        CREATE OR REPLACE TABLE dim_date AS
          SELECT d::DATE AS business_date, year(d) AS calendar_year,
                 quarter(d) AS calendar_quarter, month(d) AS calendar_month,
                 week(d) AS iso_week, isoyear(d) AS iso_year,
                 year(d)*10+quarter(d) AS quarter_key
          FROM generate_series(DATE '2025-01-01',DATE '2027-12-31',INTERVAL 1 DAY) t(d);
        CREATE OR REPLACE TABLE dim_quarter AS
          SELECT DISTINCT quarter_key,calendar_year AS fiscal_year,
                 calendar_quarter AS fiscal_quarter,
                 make_date(calendar_year,(calendar_quarter-1)*3+1,1) AS quarter_start
          FROM dim_date;
        CREATE OR REPLACE TABLE fact_order AS
          SELECT order_id, coalesce(customer_id,0) AS customer_id,
                 coalesce(selling_store_id,0) AS selling_store_id,
                 coalesce(pickup_store_id,0) AS pickup_store_id,
                 CASE WHEN fulfillment='carryout' THEN coalesce(selling_store_id,0)
                      WHEN fulfillment='bopis' THEN coalesce(pickup_store_id,0) ELSE 0 END AS credit_store_id,
                 timezone('America/New_York',timezone('UTC',order_ts))::DATE AS sale_date,
                 timezone('America/New_York',timezone('UTC',pickup_ts))::DATE AS pickup_date,
                 order_ts,channel,fulfillment,order_status,discount_amount,shipping_amount,tax_amount
          FROM src.orders;
        CREATE OR REPLACE TABLE fact_sale AS
          SELECT i.order_item_id,i.order_id,i.product_id,o.customer_id,o.selling_store_id,
                 o.pickup_store_id,o.credit_store_id,o.sale_date,o.order_status,o.fulfillment,
                 i.quantity,i.unit_price,i.line_discount,
                 i.quantity*i.unit_price-i.line_discount AS line_revenue
          FROM src.order_items i JOIN fact_order o USING(order_id);
        CREATE OR REPLACE TABLE fact_return AS
          SELECT r.return_id,r.order_item_id,s.order_id,s.product_id,s.customer_id,
                 s.credit_store_id,coalesce(r.return_store_id,0) AS return_store_id,
                 s.sale_date,timezone('America/New_York',timezone('UTC',r.return_ts))::DATE AS return_date,
                 s.order_status,r.quantity,r.refund_amount,r.reason_code
          FROM src.returns r JOIN fact_sale s USING(order_item_id);
        CREATE OR REPLACE TABLE fact_traffic AS SELECT store_id,business_date,visitor_count FROM src.store_traffic;
        CREATE OR REPLACE TABLE fact_target AS
          SELECT store_id,fiscal_year*10+fiscal_quarter AS quarter_key,revenue_target FROM src.store_targets;
        CREATE OR REPLACE VIEW sale_net AS
          SELECT s.*,coalesce(r.refund_amount,0) AS refund_amount,
                 s.line_revenue-coalesce(r.refund_amount,0) AS net_revenue
          FROM fact_sale s LEFT JOIN
             (SELECT order_item_id,sum(refund_amount) AS refund_amount FROM fact_return GROUP BY order_item_id) r
          USING(order_item_id);
        """)
        keys = {'fact_order':'order_id','fact_sale':'order_item_id','fact_return':'return_id',
                'dim_store':'store_id','dim_product':'product_id','dim_customer':'customer_id','dim_date':'business_date'}
        for table,key in keys.items():
            assert c.execute(f'SELECT count(*)=count(DISTINCT {key}) FROM {table}').fetchone()[0],table
        for table,source_table in [('fact_order','orders'),('fact_sale','order_items'),('fact_return','returns'),('fact_traffic','store_traffic'),('fact_target','store_targets')]:
            assert c.execute(f'SELECT (SELECT count(*) FROM {table})=(SELECT count(*) FROM src.{source_table})').fetchone()[0],table
        c.execute('COMMIT')
        print('Built',output)

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--source',type=Path,default=ROOT/'data'/'ridgeline.duckdb')
    p.add_argument('--output',type=Path,default=ROOT/'model'/'ridgeline_star.duckdb')
    a=p.parse_args()
    build(a.source,a.output)
