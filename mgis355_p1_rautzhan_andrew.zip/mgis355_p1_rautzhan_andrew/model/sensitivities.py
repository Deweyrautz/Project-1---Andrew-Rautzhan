"""Refresh the sensitivity evidence consumed by render_reports.py."""
from pathlib import Path
import json
import duckdb
ROOT=Path(__file__).resolve().parents[1]
QUERIES={
'bur_fulfillment':"select fulfillment,sum(net_revenue) from sale_net join dim_store on credit_store_id=store_id where store_code='BUR' and order_status='completed' and sale_date>='2026-07-01' and sale_date<'2026-09-01' group by fulfillment",
'company':"select sum(line_revenue),sum(refund_amount),sum(net_revenue) from sale_net where order_status='completed' and sale_date>='2026-07-01' and sale_date<'2026-09-01'",
'promos':"select sum(discount_amount),sum(shipping_amount),sum(tax_amount) from fact_order where order_status='completed' and sale_date>='2026-07-01' and sale_date<'2026-09-01'",
'calendar':"select sum(case when s.sale_date>='2026-07-01' and s.sale_date<'2026-09-01' then s.line_revenue else 0 end),sum(case when o.order_ts>='2026-07-01' and o.order_ts<'2026-09-01' then s.line_revenue else 0 end) from fact_sale s join fact_order o using(order_id) where s.order_status='completed'",
'comparison':"select sum(case when sale_date>='2025-07-01' and sale_date<'2025-09-01' then net_revenue else 0 end),sum(case when sale_date>='2025-07-01' and sale_date<'2025-10-01' then net_revenue else 0 end),sum(case when sale_date>='2026-07-01' and sale_date<'2026-09-01' then net_revenue else 0 end) from sale_net where order_status='completed'",
'return_span':"select min(return_date),max(return_date) from fact_return",
'carryout_only_flags':"select s.store_code,sum(n.net_revenue)/(max(t.revenue_target)*62/92)*100 from sale_net n join dim_store s on n.credit_store_id=s.store_id join fact_target t on t.store_id=s.store_id and t.quarter_key=20263 where n.fulfillment='carryout' and n.order_status='completed' and n.sale_date>='2026-07-01' and n.sale_date<'2026-09-01' group by s.store_code order by 2"
}
if __name__=='__main__':
    with duckdb.connect(str(ROOT/'model/ridgeline_star.duckdb'),read_only=True) as c:
        result={key:c.execute(query).fetchall() for key,query in QUERIES.items()}
    (ROOT/'results/sensitivities.json').write_text(json.dumps(result,default=str,indent=2))
    print('Refreshed sensitivity results')
