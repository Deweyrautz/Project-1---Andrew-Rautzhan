"""Independent source checks, relational integrity, deterministic rebuild, and audit A."""
from pathlib import Path
from decimal import Decimal
import hashlib, json, subprocess, sys, tempfile
import duckdb
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'data'/'ridgeline.duckdb'
STAR=ROOT/'model'/'ridgeline_star.duckdb'
PARAMS=['2026-07-01','2026-09-01']
RAW="""
WITH ledger AS (
 SELECT CASE WHEN o.fulfillment='carryout' THEN coalesce(o.selling_store_id,0)
             WHEN o.fulfillment='bopis' THEN coalesce(o.pickup_store_id,0) ELSE 0 END store_id,
        i.quantity*i.unit_price-i.line_discount AS amount
 FROM orders o JOIN order_items i USING(order_id)
 WHERE o.order_status='completed'
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE>=CAST(? AS DATE)
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE<CAST(? AS DATE)
 UNION ALL
 SELECT CASE WHEN o.fulfillment='carryout' THEN coalesce(o.selling_store_id,0)
             WHEN o.fulfillment='bopis' THEN coalesce(o.pickup_store_id,0) ELSE 0 END,
        -r.refund_amount
 FROM returns r JOIN order_items i USING(order_item_id) JOIN orders o USING(order_id)
 WHERE o.order_status='completed'
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE>=CAST(? AS DATE)
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE<CAST(? AS DATE)
)
SELECT store_id,sum(amount) AS net_revenue FROM ledger GROUP BY store_id ORDER BY store_id
"""
AUDIT_FIXED="""
SELECT s.district_id,round(sum(o.discount_amount),2) AS promo_discount
FROM orders o JOIN stores s ON s.store_id=o.selling_store_id
WHERE o.order_status='completed' AND o.order_ts>='2026-07-01' AND o.order_ts<'2026-09-01'
GROUP BY s.district_id ORDER BY s.district_id
"""
def fingerprint(path):
    with duckdb.connect(str(path),read_only=True) as c:
        return {t:hashlib.sha256(repr(c.execute(f'SELECT * FROM "{t}" ORDER BY ALL').fetchall()).encode()).hexdigest() for (t,) in c.execute('SHOW TABLES').fetchall()}
def verify():
    source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    baseline=fingerprint(STAR)
    for _ in range(2):
        subprocess.run([sys.executable,str(ROOT/'model'/'build_star.py')],check=True)
        assert fingerprint(STAR)==baseline,'Non-repeatable rebuild'
    with tempfile.TemporaryDirectory() as tmp:
        clean=Path(tmp)/'fresh.duckdb'
        subprocess.run([sys.executable,str(ROOT/'model'/'build_star.py'),'--output',str(clean)],check=True)
        assert fingerprint(clean)==baseline,'Fresh build differs'
    with duckdb.connect(str(SOURCE),read_only=True) as raw, duckdb.connect(str(STAR),read_only=True) as star:
        actual=raw.execute(RAW,PARAMS*2).fetchall()
        expected=star.execute("SELECT credit_store_id,sum(net_revenue) FROM sale_net WHERE order_status='completed' AND sale_date>=? AND sale_date<? GROUP BY credit_store_id ORDER BY credit_store_id",PARAMS).fetchall()
        assert actual==expected,'Source/star mismatch'
        bur_id=raw.execute("SELECT store_id FROM stores WHERE store_code='BUR'").fetchone()[0]
        bur=dict(actual)[bur_id]
        company=sum(v for _,v in actual)
        pace=raw.execute('SELECT revenue_target FROM store_targets WHERE store_id=? AND fiscal_year=2026 AND fiscal_quarter=3',[bur_id]).fetchone()[0]*Decimal(62)/Decimal(92)
        queries=duckdb.extract_statements((ROOT/'data'/'queries_to_audit.sql').read_text())
        wrong=raw.execute(queries[0]).fetchall()
        fixed=raw.execute(AUDIT_FIXED).fetchall()
        audit=[{'district':d,'wrong':str(w),'correct':str(dict(fixed)[d]),'overstatement':str(w-dict(fixed)[d]),'pct':float((w/dict(fixed)[d]-1)*100)} for d,w in wrong]
        # Every star foreign-key role must resolve; source counts must be retained.
        fk_checks=0
        for table,columns,dimension,key in [
            ('fact_sale',['credit_store_id','selling_store_id','pickup_store_id'],'dim_store','store_id'),
            ('fact_order',['credit_store_id','selling_store_id','pickup_store_id'],'dim_store','store_id'),
            ('fact_return',['credit_store_id','return_store_id'],'dim_store','store_id'),
            ('fact_sale',['product_id'],'dim_product','product_id'),('fact_return',['product_id'],'dim_product','product_id'),
            ('fact_sale',['customer_id'],'dim_customer','customer_id'),('fact_order',['customer_id'],'dim_customer','customer_id'),('fact_return',['customer_id'],'dim_customer','customer_id'),
            ('fact_sale',['sale_date'],'dim_date','business_date'),('fact_order',['sale_date','pickup_date'],'dim_date','business_date'),('fact_return',['sale_date','return_date'],'dim_date','business_date'),
            ('fact_traffic',['store_id'],'dim_store','store_id'),('fact_target',['store_id'],'dim_store','store_id'),
            ('fact_traffic',['business_date'],'dim_date','business_date'),('fact_target',['quarter_key'],'dim_quarter','quarter_key')]:
            for column in columns:
                n=star.execute(f'SELECT count(*) FROM {table} f LEFT JOIN {dimension} d ON f.{column}=d.{key} WHERE f.{column} IS NOT NULL AND d.{key} IS NULL').fetchone()[0]
                assert n==0,(table,column,n)
                fk_checks+=1
        for table,keys in [('fact_traffic','store_id,business_date'),('fact_target','store_id,quarter_key')]:
            assert star.execute(f'SELECT count(*) FROM (SELECT {keys},count(*) n FROM {table} GROUP BY {keys} HAVING n<>1)').fetchone()[0]==0
        assert star.execute('SELECT count(*) FROM sale_net').fetchone()[0]==star.execute('SELECT count(*) FROM fact_sale').fetchone()[0]
        assert raw.execute('SELECT count(*) FROM returns r LEFT JOIN order_items i USING(order_item_id) WHERE i.order_item_id IS NULL').fetchone()[0]==0
        result={'source_sha256':source_hash,'company_net':str(company),'physical_store_net':str(sum(v for k,v in actual if k!=0)),'web_net':str(dict(actual)[0]),'burlington_net':str(bur),'burlington_pace_target':str(pace),'burlington_attainment_pct':float(bur/pace*100),'audit_A':audit,'foreign_key_roles_checked':fk_checks,'raw_store_totals':{str(k):str(v) for k,v in actual}}
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==source_hash
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/'verification_results.json').write_text(json.dumps(result,indent=2))
    (ROOT/'results'/'source_reconciliation.sql').write_text(RAW)
    (ROOT/'results'/'audit_A_corrected.sql').write_text(AUDIT_FIXED)
    print(json.dumps(result,indent=2))
    print('PASS: two rebuilds, fresh build, exact source reconciliation, role integrity, grains, unchanged source')
    return result
if __name__=='__main__':verify()
