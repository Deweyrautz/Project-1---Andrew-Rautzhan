# Metric register

All reported monetary values are dollars. Display rounding happens after aggregation. Definitions are proposed analytical policies, not statements of Ridgeline’s approved accounting policy. Company and physical-store scopes must not be interchanged.

## Line revenue after line markdowns

| Field | Definition |
|---|---|
| Name | Line revenue after line markdowns |
| Formula | `SUM(fact_sale.quantity * fact_sale.unit_price - fact_sale.line_discount)` |
| Grain | One sold line; additive to store/period |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Exclude order discount_amount, shipping_amount and tax_amount because overlap/policy is unresolved. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | Finance controller; provisional pending discount reconciliation |

## Observed cohort refunds

| Field | Definition |
|---|---|
| Name | Observed cohort refunds |
| Formula | `SUM(fact_return.refund_amount)` |
| Grain | One return event; aggregate by original sale cohort before joining to sales |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Include every recorded refund for eligible sold lines, even after August 31; no return-date cutoff. Never infer refunds from order_status. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. Returns debit the original credit store, not return_store_id. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. Extract metadata says mid-October; last observed local return date is October 14, 2026, which is not proof of an exact extraction timestamp. |
| Owner and status | Finance controller; provisional as late returns remain possible |

## Observed net merchandise revenue

| Field | Definition |
|---|---|
| Name | Observed net merchandise revenue |
| Formula | `SUM(sale_net.line_revenue) - SUM(sale_net.refund_amount)` |
| Grain | One sold line in sale_net, after returns are summed per line |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Only line markdowns and recorded refunds deducted; order promotions, tax and shipping excluded. Not GAAP revenue. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | Finance controller; provisional, refund maturity differs across years |

## Quarter revenue target

| Field | Definition |
|---|---|
| Name | Quarter revenue target |
| Formula | `MAX(fact_target.revenue_target) per store-quarter; SUM across distinct stores` |
| Grain | One store per quarter, never sum after line joins |
| Filters | Select quarter_key=20263; retain all fourteen physical stores; no sales-based store filtering |
| Store credit rule | Target belongs to physical store_id; web bucket has no target |
| Calendar | Fiscal Q3 assumed July–September; quarterly target provided, intraperiod schedule absent |
| Owner and status | VP of Stores / FP&A; source target accepted, comparability to net merchandise revenue provisional |

## Elapsed-period target

| Field | Definition |
|---|---|
| Name | Elapsed-period target |
| Formula | `fact_target.revenue_target * 62.0 / 92.0` |
| Grain | One store per target quarter |
| Filters | Q3 2026 only; 62 days elapsed; no seasonality or trading-day adjustment |
| Store credit rule | Physical target store_id |
| Calendar | July 1–September 1 elapsed; July 1–October 1 quarter, Eastern calendar dates |
| Owner and status | FP&A; provisional linear day allocation, not a forecast |

## Target attainment

| Field | Definition |
|---|---|
| Name | Target attainment |
| Formula | `100 * store_net_revenue / NULLIF(elapsed_period_target,0)` |
| Grain | Store-period after independent fact aggregation |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Numerator is observed net merchandise revenue; denominator from the selected quarter. No order/target fan-out. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | VP of Stores / FP&A; provisional until target basis and seasonality approved |

## Dollar gap to pace

| Field | Definition |
|---|---|
| Name | Dollar gap to pace |
| Formula | `store_net_revenue - elapsed_period_target` |
| Grain | Store-period |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Positive means ahead; no tolerance applied to the dollar gap. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | VP of Stores / FP&A; provisional |

## Below-pace flag and ranking

| Field | Definition |
|---|---|
| Name | Below-pace flag and ranking |
| Formula | `attainment_pct < 95; rank stores by attainment_pct DESC, store_code ASC` |
| Grain | Store-period |
| Filters | Include all fourteen stores; unrounded attainment determines flag; equality at 95 is within tolerance. Count flags, not rows of sales. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | VP of Stores; proposed 5 percentage point tolerance, not a statistical significance claim |

## Matched-window net growth

| Field | Definition |
|---|---|
| Name | Matched-window net growth |
| Formula | `100 * (current_net / NULLIF(prior_matched_net,0) - 1)` |
| Grain | Store-period or company-period, same aggregation on both sides |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Compare Jul–Aug with Jul–Aug, not the entire prior quarter. All observed cohort refunds included, with unequal maturity caveat. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | FP&A; provisional due to refund maturation and attribution policy |

## Carryout-only net revenue and attainment

| Field | Definition |
|---|---|
| Name | Carryout-only net revenue and attainment |
| Formula | `SUM(sale_net.net_revenue) WHERE fulfillment=carryout; 100 * carryout_net / elapsed_period_target` |
| Grain | Store-period |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Additional fulfillment=carryout; sensitivity alternative, not primary ranking. Same target and refunds basis. |
| Store credit rule | Selling store only; excludes BOPIS and shipped web |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | VP of Stores; rejected as primary store-credit definition |

## BOPIS net credit and attribution lift

| Field | Definition |
|---|---|
| Name | BOPIS net credit and attribution lift |
| Formula | `SUM(sale_net.net_revenue) WHERE fulfillment=bopis; bopis_net = credited_net - carryout_net; attainment_lift_pp = 100 * bopis_net / elapsed_period_target` |
| Grain | Store-period |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Additional fulfillment=bopis; no pickup-date filter; includes its observed refunds. |
| Store credit rule | Pickup store |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | Omnichannel operations; provisional original-order-date credit rule |

## Carryout transactions

| Field | Definition |
|---|---|
| Name | Carryout transactions |
| Formula | `COUNT(fact_order.order_id) WHERE fulfillment=carryout` |
| Grain | One completed carryout order; aggregate first to store-day |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Additional fulfillment=carryout; count checkout events, not customers or lines. Never join raw orders to traffic. |
| Store credit rule | Selling store |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | Retail operations; proposed checkout measure |

## Door visitors

| Field | Definition |
|---|---|
| Name | Door visitors |
| Formula | `SUM(fact_traffic.visitor_count)` |
| Grain | Store-local-day, additive to period |
| Filters | July–August 2026 traffic rows; all fourteen stores; no order or customer filter. Verify every sales day has traffic. |
| Store credit rule | Physical store_id |
| Calendar | fact_traffic.business_date is already local; do not timezone-shift it |
| Owner and status | Retail operations; source door-counter measure, includes nonbuyers and possibly pickups |

## Carryout conversion proxy

| Field | Definition |
|---|---|
| Name | Carryout conversion proxy |
| Formula | `100 * SUM(store_day_carryout_transactions) / NULLIF(SUM(store_day_visitors),0)` |
| Grain | Store-period after store-day aggregation |
| Filters | Same traffic-covered days in numerator and denominator; left join aggregated orders onto traffic, retaining zero-order days; do not average daily percentages. |
| Store credit rule | Physical store / selling store |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. Traffic uses its local business_date. |
| Owner and status | Retail operations; provisional proxy, not person-level conversion; repeat visits and BOPIS traffic affect interpretation |

## UTC-window line revenue sensitivity

| Field | Definition |
|---|---|
| Name | UTC-window line revenue sensitivity |
| Formula | `SUM(fact_sale.line_revenue) WHERE fact_order.order_ts >= start_utc AND fact_order.order_ts < end_utc` |
| Grain | Company-period |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Replace local-date window only; keep line revenue definition, not net revenue. Comparison uses the same company scope. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | UTC timestamps in [2026-07-01 00:00, 2026-09-01 00:00); rejected primary calendar |
| Owner and status | Finance controller; diagnostic, not approved operating calendar |

## Full-prior-quarter growth sensitivity

| Field | Definition |
|---|---|
| Name | Full-prior-quarter growth sensitivity |
| Formula | `100 * (current_JulAug_net / NULLIF(prior_JulSep_net,0) - 1)` |
| Grain | Company-period |
| Filters | Current Jul–Aug 2026 versus Jul–Sep 2025; completed orders and observed refunds as above; deliberately unequal windows |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | FP&A; rejected comparability alternative |

## Whole-quarter attainment sensitivity

| Field | Definition |
|---|---|
| Name | Whole-quarter attainment sensitivity |
| Formula | `100 * store_net_revenue / NULLIF(quarter_revenue_target,0)` |
| Grain | Store-period |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Full-quarter denominator without elapsed-day allocation; diagnostic only |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | FP&A; rejected comparison for partial-quarter performance |

## Additional-order-promotion sensitivity

| Field | Definition |
|---|---|
| Name | Additional-order-promotion sensitivity |
| Formula | `company_observed_net - SUM(fact_order.discount_amount)` |
| Grain | Company-period after separate order and line aggregation |
| Filters | Completed original orders; all products and customers including anonymous; exclude cancelled orders. No membership filter. Primary period is July 1–August 31, 2026; matched prior is July 1–August 31, 2025. Bounds are inclusive start, exclusive September 1. Subtract order promotions once per order; shipping and tax remain excluded. Overlap with line discounts is unknown. |
| Store credit rule | Carryout to selling_store_id; BOPIS to pickup_store_id; shipped web to store 0. Physical-store ranking excludes 0; company totals retain it. |
| Calendar | sale_date = UTC order_ts converted to America/New_York, then DATE; observed returns assigned to original sale_date regardless of return_date. |
| Owner and status | Finance controller; unresolved sensitivity, not approved revenue |

## Order promotions by district, audited Query A

| Field | Definition |
|---|---|
| Name | Order promotions by district, audited Query A |
| Formula | `SUM(fact_order.discount_amount) per district, without joining order lines` |
| Grain | Completed order, additive to district-period |
| Filters | Match inherited audit scope exactly: UTC Jul–Aug 2026; completed orders with a selling store. Deliberately excludes web orders so only fan-out changes. |
| Store credit rule | Selling-store district, not primary omnichannel credit rule |
| Calendar | UTC order_ts window, preserved from inherited Query A for controlled audit |
| Owner and status | Finance controller; corrected for audit scope only, not a complete company promotions report |

## Audit overstatement

| Field | Definition |
|---|---|
| Name | Audit overstatement |
| Formula | `wrong_promo - corrected_promo; 100 * (wrong_promo / NULLIF(corrected_promo,0) - 1)` |
| Grain | District audit result |
| Filters | Same scope as audited promotions; wrong output repeats each order amount once per item |
| Store credit rule | Selling-store district |
| Calendar | Inherited UTC window |
| Owner and status | Analytics reviewer; verified diagnostic |
