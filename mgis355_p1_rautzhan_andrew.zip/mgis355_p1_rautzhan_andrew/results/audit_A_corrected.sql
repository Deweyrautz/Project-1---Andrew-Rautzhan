
SELECT s.district_id,round(sum(o.discount_amount),2) AS promo_discount
FROM orders o JOIN stores s ON s.store_id=o.selling_store_id
WHERE o.order_status='completed' AND o.order_ts>='2026-07-01' AND o.order_ts<'2026-09-01'
GROUP BY s.district_id ORDER BY s.district_id
