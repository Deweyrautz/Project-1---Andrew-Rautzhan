
WITH ledger AS (
 SELECT CASE WHEN o.fulfillment='carryout' THEN coalesce(o.selling_store_id,0)
             WHEN o.fulfillment='bopis' THEN coalesce(o.pickup_store_id,0) ELSE 0 END store_id,
        i.quantity*i.unit_price-i.line_discount AS amount
 FROM orders o JOIN order_items i USING(order_id)
 WHERE o.order_status='completed'
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE>=CAST(? AS DATE)
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE<CAST(? AS DATE)
 UNION ALL
 SELECT CASE WHEN o.fulfillment='carryout' THEN coalesce(o.selling_store_id,0)
             WHEN o.fulfillment='bopis' THEN coalesce(o.pickup_store_id,0) ELSE 0 END,
        -r.refund_amount
 FROM returns r JOIN order_items i USING(order_item_id) JOIN orders o USING(order_id)
 WHERE o.order_status='completed'
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE>=CAST(? AS DATE)
 AND timezone('America/New_York',timezone('UTC',o.order_ts))::DATE<CAST(? AS DATE)
)
SELECT store_id,sum(amount) AS net_revenue FROM ledger GROUP BY store_id ORDER BY store_id
